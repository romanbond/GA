A Pen created at CodePen.io. You can find this one at http://codepen.io/imfelix/pen/pboQqm.

 Dribbble Shot - https://dribbble.com/shots/2745508-Minimal-Call-To-Action